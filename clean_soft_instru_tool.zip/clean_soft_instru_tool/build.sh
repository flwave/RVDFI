#!/bin/bash

export target=${1}

export COMPILECHAIN=xxx/riscv-gnu-build-linux/bin/riscv64-unknown-linux-gnu-
export RISCVCXXLIBPATH=xxx/riscv-gnu-build-linux/riscv64-unknown-linux-gnu/include/c++/7.2.0
export LLVMPATH=xxx/llvm-7.0.0/build-riscv-release
export LLVMPATH2=xxx/llvm-11.0.0/build-riscv-release
export SVFPATH=xxx/SVF/Release-build
export PROGPATH=./
export WORKPATH=./

echo "target is" ${target}

source ${PROGPATH}/compile_${1}.sh

echo "----------benchmark compile done----------"

$LLVMPATH/bin/clang++ -emit-llvm -c -I${RISCVCXXLIBPATH} -I ${RISCVCXXLIBPATH}/riscv64-unknown-linux-gnu/ ${PROGPATH}/dfi_inst.cc -lstdc++ -o dfi_inst.bc 
$LLVMPATH/bin/llvm-link ${target}.bc dfi_inst.bc  -o ${target}.bc

$LLVMPATH/bin/llvm-dis dfi_inst.bc

echo "----------link initialization done----------"

$SVFPATH/bin/wpa -ander -gen-def-set -print-def-set -print-prog-id ${target}.bc > ${target}.rd

echo "----------static analysis done----------"

$LLVMPATH/bin/llvm-dis ${target}.wpa
cp ${target}.wpa.ll ${target}.ll
cp ${target}.wpa ${target}.bc

python ${PROGPATH}/IR_instrumentation.py ${target} -soft -sfunc dfi_inst -usrrds usr_rds_${target}

$LLVMPATH/bin/llvm-as ${target}.ll -o ${target}.bc

$LLVMPATH2/bin/llc -O0 -march=riscv64 -mcpu=generic-rv64 -mattr=+a,+c,+d,+f,+m ${target}.bc -o ${target}.s
sed -i 's/\.attribute.*//g' ${target}.s
${COMPILECHAIN}g++ -I${RISCVCXXLIBPATH} -I ${RISCVCXXLIBPATH}/riscv64-unknown-linux-gnu/  ${target}.s -O0 -L./ -lpthread -lstdc++ -lm -o ${target}
${COMPILECHAIN}objdump -d ${target} > ${target}.od

echo "----------soft mode done----------"

