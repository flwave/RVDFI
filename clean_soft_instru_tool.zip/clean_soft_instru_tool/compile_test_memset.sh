$LLVMPATH/bin/clang -emit-llvm -c -o test_memset.bc ${PROGPATH}/test_memset.c -O0 -lpthread
