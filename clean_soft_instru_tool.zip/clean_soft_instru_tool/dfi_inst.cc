#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <cstring>
#include <iomanip>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h> 

unsigned short *dfi_reg_s;
unsigned short *dfi_vio;

void init_soft_dfi(){
	std::cout<<"init soft dfi"<<std::endl;
	/*
	int fp=open("/dev/mem",O_RDWR|O_SYNC);
	if(fp<0){
		std::cout<<"cannot open /dev/mem"<<std::endl;
		exit(0);
	}
	vmem=mmap(NULL,0x6000000,PROT_READ|PROT_WRITE,MAP_SHARED,fp,0xf4084000);
	if(vmem==NULL){
		std::cout<<"cannot map physical address"<<std::endl;
		exit(0);
	}
	
	dfi_reg_s=vmem;
	*/
	std::cout<<"init ready to allocate rdt region"<<std::endl;
	dfi_reg_s=(unsigned short*)malloc(128*1024*1024+128);//this is for rdt
	dfi_vio=(unsigned short*)malloc(2);//this is for a flag of violation
	dfi_vio[0]=0;
	printf("%x\n",(unsigned long)__builtin_frame_address(0));//might be able to be deleted under x86
	std::cout<<"init dfi end"<<std::endl;
}

void dfi_debug(){
	printf("DEBUG: debug begin\n");
	printf("Violation flag: %d\n",dfi_vio[0]);
	unsigned long a=(unsigned long)__builtin_frame_address(0);
	exit(0);
}
