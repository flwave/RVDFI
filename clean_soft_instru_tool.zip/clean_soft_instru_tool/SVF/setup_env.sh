export LLVM_ROOT=/home/lf/llvm-6.0.0/
export CC=clang
export CXX=clang++
export LLVM_SRC=/home/lf/llvm-6.0.0/llvm-6.0.0.src/
export LLVM_OBJ=/home/lf/llvm-6.0.0/build/
export LLVM_DIR=/home/lf/llvm-6.0.0/build/
export SVF_HOME=${PWD}
export PATH=${SVF_HOME}/build/bin:$PATH
