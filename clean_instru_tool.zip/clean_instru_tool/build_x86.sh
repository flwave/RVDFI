#!/bin/bash

export target=${1}

export LLVMPATH=/home/lf/llvm-6.0.0/build-release
export SVFPATH=/home/lf/SVF/Release-build
export PROGPATH=./
export WORKPATH=./

echo "target is" ${target}

source ${PROGPATH}/compile_${1}.sh

echo "----------benchmark compile done----------"

$LLVMPATH/bin/clang++ -emit-llvm -c ${PROGPATH}/dfi_inst.cc -lstdc++ -o dfi_inst.bc 
$LLVMPATH/bin/llvm-link ${target}.bc dfi_inst.bc  -o ${target}.bc

$LLVMPATH/bin/llvm-dis dfi_inst.bc

echo "----------link initialization done----------"

$SVFPATH/bin/wpa -ander -gen-def-set -print-def-set -print-prog-id ${target}.bc > ${target}.rd

echo "----------static analysis done----------"

$LLVMPATH/bin/llvm-dis ${target}.wpa
cp ${target}.wpa.ll ${target}.ll
cp ${target}.wpa ${target}.bc

python ${PROGPATH}/IR_instrumentation.py ${target} -soft -sfunc dfi_inst -debugfunc -usrrds usr_rds_${target}

$LLVMPATH/bin/llvm-as ${target}.ll -o ${target}.bc 

$LLVMPATH/bin/llc -O0 ${target}.bc -o ${target}.s

g++ ${target}.s -O0 -L./ -lpthread -lstdc++ -lm -o ${target}
objdump -d ${target} > ${target}.od

echo "----------soft mode done----------"
