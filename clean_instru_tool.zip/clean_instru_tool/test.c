#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 

int main() 
{
	int a[4];
	int b[4];
	int c[4];
        printf("a's address %x, b's address %x, c's address %x\n",a,b,c);
	int i;
	for(i=0;i<4;i++)
	a[i]=0;
	for(i=0;i<4;i++)
	b[i]=0;
	for(i=0;i<4;i++)
    c[i]=0;
	
	for(i=0;i<4;i++) //if you modify "i<4" to any number >4, such as "i<5", the violation can be detected
	b[i]=i;
	
	for(i=0;i<4;i++)
	printf("%d\n",a[i]);
	for(i=0;i<4;i++)
	printf("%d\n",b[i]);
	for(i=0;i<4;i++)
    printf("%d\n",c[i]);
    return 0;
}


