#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h>

int main() 
{
	int a[4];
	int b[4];
	int c[4];
        printf("a's address %x, b's address %x, c's address %x\n",a,b,c);
	int i;
	for(i=0;i<4;i++)
	a[i]=0;
	for(i=0;i<4;i++)
	b[i]=0;
	for(i=0;i<4;i++)
    c[i]=0;
	
	memset(b,2,4*4);//if you modify the copy size >4, the violation can be detected
	
	for(i=0;i<4;i++)
	printf("%d\n",a[i]);
	for(i=0;i<4;i++)
	printf("%d\n",b[i]);
	for(i=0;i<4;i++)
    printf("%d\n",c[i]);
    return 0;
}


