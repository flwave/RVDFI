import re
import sys
import math
import copy
import numpy
import random
import pickle

sfunc={'init_soft_dfi':'','dfi_debug':''}

nopinst='call void asm "add x0,x0,x0", "~{dirflag},~{fpsr},~{flags}"() #2'

nopinst2='call void asm "nop", "~{dirflag},~{fpsr},~{flags}"() #2'

nonexcluded=['dfi_o3_flush']

valid_intrinsic_func=['memcpy','memset','memmove']

ts_insert_line_ratio=0.15

exfuncs=[]
sfuncfile=''

debugfunc=0

usr_rds=0
usr_rds_file=''

timestampfunc='main'
endtimestamp=0

exp_mode='noinstr'

sp_len=32
bf_len=32
max_hist=3
analysis=0
rand_del=0
rand_del_ptg=0
rand_del_file_suffix=''
show_del=0
show_del_range=0
load_del=0
load_del_name=''

hdfi_mode=0

runtoend=0

anyfunc=0
nofunc=0
noload=0
nostore=0

#the index is the index of the input, if we need the output, the index is the # of inputs
#d=func(a,b,c), if we need b, index=1, if we need d, index=3
#if len is a list [k], it means the usr define the length is k
#pos means the position of the instrumentation, 0 means before, 1 means after
sp_inst_funcs=[
{'name':'NA','s':[],'l':[],'len':[0],'pos':0},
{'name':'memcpy','s':0,'l':1,'len':2,'pos':0},
{'name':'memset','s':0,'l':[],'len':2,'pos':0},
{'name':'memmove','s':0,'l':1,'len':2,'pos':0},
{'name':'BIO_write','s':0,'l':1,'len':2,'pos':0},
{'name':'read_wrapper','s':1,'l':[],'len':3,'pos':0},
{'name':'longjmp','s':[],'l':0,'len':[1],'pos':0},
{'name':'strncpy','s':0,'l':1,'len':2,'pos':0},
{'name':'strncat','s':0,'l':1,'len':2,'pos':0},
]

#regular expressions of where to insert debug functions
#default: function return
insert_debug_rules=[
'^\s*ret',
'call void @mylongjmp\(',
'%\d+ = call signext i\d+ %\d+\(.*\)',
]

ret_id=0

spatt_dop=0

thre_soft_gem5=3

#user change this in this text file manually
signal_delay=0

def read_file(filename):
	f=open(filename,'r')
	text=f.readlines()
	f.close()
	return text

def strcmp_head(string,parts):
	for p in parts:
		if len(p)<=len(string) and string[0:len(p)]==p:
			return 1
	return 0

def split_misc(string):
	r=re.findall('(\S+)',string)
	if len(r)==0:
		return [],''
	for i in range(len(r)):
		if r[i][-1]!=',':
			break
	misc=''
	for j in range(i+1,len(r)):
		misc+=r[j]+' '
	regs=r[0:i+1]
	for i in range(len(regs)):
		if regs[i][-1]==',':
			regs[i]=regs[i][:-1]
	
	regs_new=[]
	cont=0
	for reg in regs:
		if cont==0:
			regs_new.append('')
		if '[' in reg or '{' in reg:
			cont=1
		if cont and (']' in reg or '}' in reg):
			cont=0
		regs_new[-1]+=reg
		if cont:
			regs_new[-1]+=','
	return regs_new,misc

def parse_analysis(text):
	state=0
	idinst=[]
	rds=[]
	nid=-1
	func=0
	func_name=""
	for t in text:
		if state==0:
			if t=="============= Program with IDs =============\n":
				print "Start Parsing Program with ID"
				state=1
		elif state==1:
			if t=="============= Reaching Definition Set ===============\n":
				print "Start Parsing reaching definition set"
				state=2
		if state==1:
			if t=="\n":#next valid line is the first line of a function
				func=1
			else:
				exp="(\d+)\s+(.*)"
				r=re.findall(exp,t)
				if len(r)>0:
					if func:#this line is a function name
						exp="\d+\s+(\S+)\(.*\)"
						r2=re.findall(exp,t)
						func_name=r2[0]
						func=0
					else:
						exp2="^\s*\S+ = load .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'l',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
						exp2="^\s*store .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'s',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
						exp2="^\s*br .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'br',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
						exp2="^\s*\S+ = call .*|\s*call .*|\S+ = tail call .*|\s*tail call .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'bc',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
						exp2="^\s*switch .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'bs',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
						exp2="^\s*ret .*"
						r2=re.findall(exp2,r[0][1])
						if len(r2)>0:
							idinst.append({"type":'bt',"id":int(r[0][0]),"inst":r[0][1],"func":func_name,"rds":[],"addr":[],"del":0,'matched':0})
							continue
		elif state==2:
			exp="NodeID (\d+)"
			r=re.findall(exp,t)
			if len(r)>0:
				nid=int(r[0])
				continue
			if nid>=0:
				exp=": ReachDefSet \{ (.*) \}"
				r=re.findall(exp,t)
				if len(r)>0 and r[0]!="empty":
					rds_temp=r[0].split(" ")
					for i in range(len(rds_temp)):
						rds_temp[i]=int(rds_temp[i])
					rds.append({"nid":nid,"rds":rds_temp})
	
	print "Start writing reaching definition set into parsed program"
	i_i=0
	i_r=0
	
	while i_i<len(idinst) and i_r<len(rds):
		if idinst[i_i]["id"]<rds[i_r]["nid"]:
			i_i+=1
		elif idinst[i_i]["id"]<rds[i_r]["nid"]:
			i_r+=1
		else:
			idinst[i_i]["rds"]=rds[i_r]["rds"]
			i_i+=1
			i_r+=1
	"""
	i=0
	for ii in idinst:
		for r in rds:
			if ii["id"]==r["nid"]:
				idinst[i]["rds"]=r["rds"]
				break
		i+=1
	"""
	return idinst

def check_if_special_inst_func(inst):
	if nofunc:
		return -1
	r=re.findall('@(\S+)\(',inst)
	if len(r)>0:
		i=0
		for sf in sp_inst_funcs:
			r2=re.findall(sf['name'],r[0])
			if len(r2)>0:
				return i
			i+=1
	if anyfunc:
		return 0
	else:
		return -1

def check_if_special_inst_func_lite(name):
	if nofunc:
		return -1
	i=0
	for sf in sp_inst_funcs:
		r2=re.findall(sf['name'],name)
		if len(r2)>0:
			return i
		i+=1
	if anyfunc:
		return 0
	else:
		return -1

def inst_debug(text):
	i=0
	state=0
	line_inst=[]
	while i<len(text):
		exp='define .* @\S*'+timestampfunc+'\S*\(.*\) .* \{'
		if state==0:
			if len(re.findall(exp,text[i]))>0:
				state=1
		elif state==1:
			if len(re.findall('^\}',text[i]))>0:
				break
			for exp in insert_debug_rules:
				if len(re.findall(exp,text[i]))>0:
					line_inst.append(i)
		i+=1
	line_inst.reverse()
	for l in line_inst:
		text.insert(l,'call void @'+sfunc['dfi_debug']+'()\n')

def inst_init(fake,base_id):
	if fake:
		if exp_mode=="soft":
			return 12
	string=[]
	if exp_mode=="soft":
		string.append('%'+str(base_id)+' = load i16*, i16** @dfi_reg_s, align 4\n')
		string.append('%'+str(base_id+1)+' = load i16*, i16** @dfi_vio, align 4\n')
		string.append('%'+str(base_id+2)+' = call i8* @llvm.frameaddress(i32 0)\n')
		string.append('%'+str(base_id+3)+' = ptrtoint i8* %'+str(base_id+2)+' to i32\n')
		
		string.append('%'+str(base_id+4)+' = icmp eq i32 %'+str(base_id+3)+', 4294967295\n')
		string.append('br i1 %'+str(base_id+4)+', label %'+str(base_id+5)+', label %'+str(base_id+6)+'\n')
		string.append('; <label>:'+str(base_id+5)+':\n')
		string.append('br label %'+str(base_id+11)+'\n')
		string.append('; <label>:'+str(base_id+6)+':\n')
		string.append('%'+str(base_id+7)+' = mul nsw i32 32, %'+str(base_id+3)+'\n')
		string.append('%'+str(base_id+8)+' = lshr i32 %'+str(base_id+7)+', 7\n')
		string.append('%'+str(base_id+9)+' = add nsw i32 10, %'+str(base_id+8)+'\n')
		string.append('%'+str(base_id+10)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(base_id)+', i32 %'+str(base_id+9)+'\n')
		string.append('store i'+str(bf_len)+' '+str(ret_id)+', i'+str(bf_len)+'* %'+str(base_id+10)+', align '+str(bf_len/8)+'\n')
		string.append('br label %'+str(base_id+11)+'\n')
		string.append('; <label>:'+str(base_id+11)+':\n')
	return string

def inst_sl_old_4(fake,base_id,init_base_id,load_from,node_id,sl,rds,pos):
	#added the memcpt etc. functions
	#changed l/r shift bits
	load_from=copy.deepcopy(load_from)
	if fake:#only return the instrumentation length
		if sl=='s':
			if pos==0:
				return 0
			return 9
		elif sl=='l':
			if pos==0:
				return 0
			now_id=6
			parts=inst_sl_old_find_cont(rds)
			if len(parts)==0:
				now_id+=1
			for p in parts:
				if len(p)<=2:
					for d in p:
						now_id+=2
				elif p[0]==0:
					now_id+=2
				else:
					now_id+=4
			now_id+=2
			return now_id
		elif len(sl)>=3 and sl[0:2]=='bc':
			lib_p=int(sl[2:])
			lib_s=sp_inst_funcs[lib_p]['s']
			lib_l=sp_inst_funcs[lib_p]['l']
			lib_len=sp_inst_funcs[lib_p]['len']
			if type(lib_len)==list:
				if lib_len[0]<(1<<32):
					load_from.append(' i32 '+str(lib_len[0])+' ')
				else:
					load_from.append(' i64 '+str(lib_len[0])+' ')
				lib_len=len(load_from)-1
			r=re.sub("align \d+","",load_from[lib_len])
			r=re.sub("nonnull","",r)
			r=re.findall("^\s*i(\d+)(.*)",r)
			rlen=int(r[0][0])
			rfrom=r[0][1]
			target=[]
			if lib_s!=[]:
				target=re.sub("align \d+","",load_from[lib_s])
				target=re.sub("nonnull","",target)
			source=[]
			if lib_l!=[]:
				source=re.sub("align \d+","",load_from[lib_l])
				source=re.sub("nonnull","",source)
			now_id=0
			if source!=[]:
				now_id+=13
				parts=inst_sl_old_find_cont(rds)
				if len(parts)==0:
					now_id+=1
				for p in parts:
					if len(p)<=2:
						for d in p:
							now_id+=2
					elif p[0]==0:
						now_id+=2
					else:
						now_id+=4
				now_id+=7
			if target!=[]:
				now_id+=21
			return now_id
		elif sl=='bt':
			now_id=5
			now_id+=2
			now_id+=2
			return now_id
		else:
			return 0
	if sl=='s':
		if pos==0:
			return []
		string=[]
		string.append('%'+str(base_id)+' = ptrtoint '+load_from+' to i32\n')
		string.append('%'+str(base_id+1)+' = icmp eq i32 %'+str(base_id)+', 4294967295\n')
		string.append('br i1 %'+str(base_id+1)+', label %'+str(base_id+2)+', label %'+str(base_id+3)+'\n')
		string.append('; <label>:'+str(base_id+2)+':\n')
		string.append('br label %'+str(base_id+8)+'\n')
		string.append('; <label>:'+str(base_id+3)+':\n')
		string.append('%'+str(base_id+4)+' = mul nsw i32 32, %'+str(base_id)+'\n')
		string.append('%'+str(base_id+5)+' = lshr i32 %'+str(base_id+4)+', 7\n')
		string.append('%'+str(base_id+6)+' = add nsw i32 10, %'+str(base_id+5)+'\n')
		string.append('%'+str(base_id+7)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 %'+str(base_id+6)+'\n')
		string.append('store i'+str(bf_len)+' '+str(node_id)+', i'+str(bf_len)+'* %'+str(base_id+7)+', align '+str(bf_len/8)+'\n')
		string.append('br label %'+str(base_id+8)+'\n')
		string.append('; <label>:'+str(base_id+8)+':\n')
	elif sl=='l':
		if pos==0:
			return []
		string=[]
		string.append('%'+str(base_id)+' = ptrtoint '+load_from+' to i32\n')
		string.append('%'+str(base_id+1)+' = mul nsw i32 32, %'+str(base_id)+'\n')
		string.append('%'+str(base_id+2)+' = lshr i32 %'+str(base_id+1)+', 7\n')
		string.append('%'+str(base_id+3)+' = add nsw i32 10, %'+str(base_id+2)+'\n')
		string.append('%'+str(base_id+4)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 %'+str(base_id+3)+'\n')
		#string.append('store i32 '+str(node_id)+', i32* %'+str(base_id+8)+', align 4\n')
		string.append('%'+str(base_id+5)+' = load i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(base_id+4)+', align '+str(bf_len/8)+'\n')
		now_id=base_id+5
		parts=inst_sl_old_find_cont(rds)
		final_id=now_id
		if len(parts)==0:
			final_id+=1
		for p in parts:
			if len(p)<=2:
				for d in p:
					final_id+=2
			elif p[0]==0:
				final_id+=2
			else:
				final_id+=4
		if len(parts)==0:
			string.append('br label %'+str(final_id+2)+'\n')
			string.append('; <label>:'+str(now_id+1)+':\n')
			now_id+=1
		for p in parts:
			if len(p)<=2:#no need to do d1<x<d2 comparison
				for d in p:
					string.append('%'+str(now_id+1)+' = icmp eq i'+str(bf_len)+' %'+str(base_id+5)+', '+str(d)+'\n')
					string.append('br i1 %'+str(now_id+1)+', label %'+str(final_id+2)+', label %'+str(now_id+2)+'\n')
					string.append('; <label>:'+str(now_id+2)+':\n')
					now_id+=2
			elif p[0]==0:#do one comparision
				string.append('%'+str(now_id+1)+' = icmp ule i'+str(bf_len)+' %'+str(base_id+5)+', '+str(p[-1])+'\n')
				string.append('br i1 %'+str(now_id+1)+', label %'+str(final_id+2)+', label %'+str(now_id+2)+'\n')
				string.append('; <label>:'+str(now_id+2)+':\n')
				now_id+=2
			else:#do two comparisions
				string.append('%'+str(now_id+1)+' = icmp uge i'+str(bf_len)+' %'+str(base_id+5)+', '+str(p[0])+'\n')
				string.append('br i1 %'+str(now_id+1)+', label %'+str(now_id+2)+', label %'+str(now_id+4)+'\n')
				string.append('; <label>:'+str(now_id+2)+':\n')
				string.append('%'+str(now_id+3)+' = icmp ule i'+str(bf_len)+' %'+str(base_id+5)+', '+str(p[-1])+'\n')
				string.append('br i1 %'+str(now_id+3)+', label %'+str(final_id+2)+', label %'+str(now_id+4)+'\n')
				string.append('; <label>:'+str(now_id+4)+':\n')
				now_id+=4
		string.append('%'+str(final_id+1)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id+1)+', i32 0\n')
		string.append('store i'+str(bf_len)+' 1, i'+str(bf_len)+'* %'+str(final_id+1)+', align '+str(bf_len/8)+'\n')
		string.append('br label %'+str(final_id+2)+'\n')
		string.append('; <label>:'+str(final_id+2)+':\n')
	elif len(sl)>=3 and sl[0:2]=='bc':
		lib_p=int(sl[2:])
		lib_s=sp_inst_funcs[lib_p]['s']
		lib_l=sp_inst_funcs[lib_p]['l']
		lib_len=sp_inst_funcs[lib_p]['len']
		if type(lib_len)==list:
			if lib_len[0]<(1<<32):
				load_from.append(' i32 '+str(lib_len[0])+' ')
			else:
				load_from.append(' i64 '+str(lib_len[0])+' ')
			lib_len=len(load_from)-1
		r=re.sub("align \d+","",load_from[lib_len])
		r=re.sub("nonnull","",r)
		r=re.findall("^\s*i(\d+)(.*)",r)
		rlen=int(r[0][0])
		rfrom=r[0][1]
		target=[]
		if lib_s!=[]:
			target=re.sub("align \d+","",load_from[lib_s])
			target=re.sub("nonnull","",target)
		source=[]
		if lib_l!=[]:
			source=re.sub("align \d+","",load_from[lib_l])
			source=re.sub("nonnull","",source)
		
		string=[]
		final_id=base_id
		if source!=[]:
			parts=inst_sl_old_find_cont(rds)
			final_id=base_id+12
			if len(parts)==0:
				final_id+=1
			for p in parts:
				if len(p)<=2:
					for d in p:
						final_id+=2
				elif p[0]==0:
					final_id+=2
				else:
					final_id+=4
			string.append('%'+str(base_id)+' = alloca i'+str(rlen)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(base_id+1)+' = alloca i32, align 4\n')
			string.append('store i'+str(rlen)+' 0, i'+str(rlen)+'* %'+str(base_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(base_id+2)+' = ptrtoint '+source+' to i32\n')
			string.append('store i32 %'+str(base_id+2)+', i32* %'+str(base_id+1)+', align 4\n')
			string.append('br label %'+str(base_id+3)+'\n')
			string.append('; <label>:'+str(base_id+3)+':\n')
			string.append('%'+str(base_id+4)+' = load i'+str(rlen)+', i'+str(rlen)+'* %'+str(base_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(base_id+5)+' = icmp sge i'+str(rlen)+' %'+str(base_id+4)+', '+rfrom+'\n')
			string.append('br i1 %'+str(base_id+5)+', label %'+str(final_id+7)+', label %'+str(base_id+6)+'\n')
			string.append('; <label>:'+str(base_id+6)+':\n')
			
			string.append('%'+str(base_id+7)+' = load i32, i32* %'+str(base_id+1)+', align 4\n')
			string.append('%'+str(base_id+8)+' = mul nsw i32 32, %'+str(base_id+7)+'\n')
			string.append('%'+str(base_id+9)+' = lshr i32 %'+str(base_id+8)+', 7\n')
			string.append('%'+str(base_id+10)+' = add nsw i32 10, %'+str(base_id+9)+'\n')
			string.append('%'+str(base_id+11)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 %'+str(base_id+10)+'\n')
			string.append('%'+str(base_id+12)+' = load i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(base_id+11)+', align '+str(bf_len/8)+'\n')
			now_id=base_id+12
			if len(parts)==0:
				string.append('br label %'+str(final_id+2)+'\n')
				string.append('; <label>:'+str(now_id+1)+':\n')
				now_id+=1
			for p in parts:
				if len(p)<=2:#no need to do d1<x<d2 comparison
					for d in p:
						string.append('%'+str(now_id+1)+' = icmp eq i'+str(bf_len)+' %'+str(base_id+12)+', '+str(d)+'\n')
						string.append('br i1 %'+str(now_id+1)+', label %'+str(final_id+2)+', label %'+str(now_id+2)+'\n')
						string.append('; <label>:'+str(now_id+2)+':\n')
						now_id+=2
				elif p[0]==0:#do one comparision
					string.append('%'+str(now_id+1)+' = icmp ule i'+str(bf_len)+' %'+str(base_id+12)+', '+str(p[-1])+'\n')
					string.append('br i1 %'+str(now_id+1)+', label %'+str(final_id+2)+', label %'+str(now_id+2)+'\n')
					string.append('; <label>:'+str(now_id+2)+':\n')
					now_id+=2
				else:#do two comparisions
					string.append('%'+str(now_id+1)+' = icmp uge i'+str(bf_len)+' %'+str(base_id+12)+', '+str(p[0])+'\n')
					string.append('br i1 %'+str(now_id+1)+', label %'+str(now_id+2)+', label %'+str(now_id+4)+'\n')
					string.append('; <label>:'+str(now_id+2)+':\n')
					string.append('%'+str(now_id+3)+' = icmp ule i'+str(bf_len)+' %'+str(base_id+12)+', '+str(p[-1])+'\n')
					string.append('br i1 %'+str(now_id+3)+', label %'+str(final_id+2)+', label %'+str(now_id+4)+'\n')
					string.append('; <label>:'+str(now_id+4)+':\n')
					now_id+=4
			string.append('%'+str(final_id+1)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 0\n')
			string.append('store i'+str(bf_len)+' 1, i'+str(bf_len)+'* %'+str(final_id+1)+', align '+str(bf_len/8)+'\n')
			string.append('br label %'+str(final_id+2)+'\n')
			string.append('; <label>:'+str(final_id+2)+':\n')
			
			string.append('%'+str(final_id+3)+' = load i'+str(rlen)+', i'+str(rlen)+'* %'+str(base_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+4)+' = add nsw i'+str(rlen)+' %'+str(final_id+3)+', 4\n')
			string.append('store i'+str(rlen)+' %'+str(final_id+4)+', i'+str(rlen)+'* %'+str(base_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+5)+' = load i32, i32* %'+str(base_id+1)+', align 4\n')
			string.append('%'+str(final_id+6)+' = add nsw i32 %'+str(final_id+5)+', 4\n')
			string.append('store i32 %'+str(final_id+6)+', i32* %'+str(base_id+1)+', align 4\n')
			string.append('br label %'+str(base_id+3)+'\n')
			string.append('; <label>:'+str(final_id+7)+':\n')
			
			final_id=final_id+8
		if target!=[]:
			string.append('%'+str(final_id)+' = alloca i'+str(rlen)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+1)+' = alloca i32, align 4\n')
			string.append('store i'+str(rlen)+' 0, i'+str(rlen)+'* %'+str(final_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+2)+' = ptrtoint '+target+' to i32\n')
			string.append('store i32 %'+str(final_id+2)+', i32* %'+str(final_id+1)+', align 4\n')
			string.append('br label %'+str(final_id+3)+'\n')
			string.append('; <label>:'+str(final_id+3)+':\n')
			string.append('%'+str(final_id+4)+' = load i'+str(rlen)+', i'+str(rlen)+'* %'+str(final_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+5)+' = icmp sge i'+str(rlen)+' %'+str(final_id+4)+', '+rfrom+'\n')
			string.append('br i1 %'+str(final_id+5)+', label %'+str(final_id+20)+', label %'+str(final_id+6)+'\n')
			string.append('; <label>:'+str(final_id+6)+':\n')
			
			string.append('%'+str(final_id+7)+' = load i32, i32* %'+str(final_id+1)+', align 4\n')
			string.append('%'+str(final_id+8)+' = icmp eq i32 %'+str(final_id+7)+', 4294967295\n')
			string.append('br i1 %'+str(final_id+8)+', label %'+str(final_id+9)+', label %'+str(final_id+10)+'\n')
			string.append('; <label>:'+str(final_id+9)+':\n')
			string.append('br label %'+str(final_id+15)+'\n')
			string.append('; <label>:'+str(final_id+10)+':\n')
			string.append('%'+str(final_id+11)+' = mul nsw i32 32, %'+str(final_id+7)+'\n')
			string.append('%'+str(final_id+12)+' = lshr i32 %'+str(final_id+11)+', 7\n')
			#string.append('%'+str(final_id+11)+' = lshr i32 %'+str(final_id+7)+', 2\n')
			#string.append('%'+str(final_id+12)+' = mul nsw i32 2, %'+str(final_id+11)+'\n')
			string.append('%'+str(final_id+13)+' = add nsw i32 10, %'+str(final_id+12)+'\n')
			#string.append('%'+str(final_id+14)+' = and i32 %'+str(final_id+13)+', 1048575\n')
			string.append('%'+str(final_id+14)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 %'+str(final_id+13)+'\n')
			string.append('store i'+str(bf_len)+' '+str(node_id)+', i'+str(bf_len)+'* %'+str(final_id+14)+', align '+str(bf_len/8)+'\n')
			string.append('br label %'+str(final_id+15)+'\n')
			string.append('; <label>:'+str(final_id+15)+':\n')
		
			string.append('%'+str(final_id+16)+' = load i'+str(rlen)+', i'+str(rlen)+'* %'+str(final_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+17)+' = add nsw i'+str(rlen)+' %'+str(final_id+16)+', 4\n')
			string.append('store i'+str(rlen)+' %'+str(final_id+17)+', i'+str(rlen)+'* %'+str(final_id)+', align '+str(rlen/8)+'\n')
			string.append('%'+str(final_id+18)+' = load i32, i32* %'+str(final_id+1)+', align 4\n')
			string.append('%'+str(final_id+19)+' = add nsw i32 %'+str(final_id+18)+', 4\n')
			string.append('store i32 %'+str(final_id+19)+', i32* %'+str(final_id+1)+', align 4\n')
			string.append('br label %'+str(final_id+3)+'\n')
			string.append('; <label>:'+str(final_id+20)+':\n')
	elif sl=='bt':
		string=[]
		string.append('%'+str(base_id)+' = mul nsw i32 32, %'+str(init_base_id+3)+'\n')
		string.append('%'+str(base_id+1)+' = lshr i32 %'+str(base_id)+', 7\n')
		string.append('%'+str(base_id+2)+' = add nsw i32 10, %'+str(base_id+1)+'\n')
		string.append('%'+str(base_id+3)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id)+', i32 %'+str(base_id+2)+'\n')
		string.append('%'+str(base_id+4)+' = load i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(base_id+3)+', align '+str(bf_len/8)+'\n')
		now_id=base_id+4
		final_id=now_id+2
		string.append('%'+str(now_id+1)+' = icmp eq i'+str(bf_len)+' %'+str(base_id+4)+', '+str(ret_id)+'\n')
		string.append('br i1 %'+str(now_id+1)+', label %'+str(final_id+2)+', label %'+str(now_id+2)+'\n')
		string.append('; <label>:'+str(now_id+2)+':\n')
		now_id+=2
		string.append('%'+str(final_id+1)+' = getelementptr inbounds i'+str(bf_len)+', i'+str(bf_len)+'* %'+str(init_base_id+1)+', i32 0\n')
		string.append('store i'+str(bf_len)+' 1, i'+str(bf_len)+'* %'+str(final_id+1)+', align '+str(bf_len/8)+'\n')
		string.append('br label %'+str(final_id+2)+'\n')
		string.append('; <label>:'+str(final_id+2)+':\n')
	else:
		string=[]
	return string

def inst_sl_none(fake,base_id,init_base_id,load_from,node_id,sl,rds,pos):
	if fake:#only return the instrumentation length
		return 0
	return []

def inst_sl_old_find_cont(rds):
	#find out the continous parts in the reaching definition set
	parts=[]
	now_id=-2
	for r in rds:
		if r!=now_id+1:
			parts.append([r])
		else:
			parts[-1].append(r)
		now_id=r
	return parts#parts is sorted

def inst_sl(fake,base_id,init_base_id,load_from,node_id,sl,rds,pos):
	if exp_mode=='soft':
		return inst_sl_old_4(fake,base_id,init_base_id,load_from,node_id,sl,rds,pos)

def inst_cmp_rd_ll(tp,rd,ll):
	if tp=='s' or tp=='l':
		exp="\S+.*align \S+"
		r_rd=re.findall(exp,rd)
		r_ll=re.findall(exp,ll)
		if r_rd==r_ll:
			return 1
		else:
			return 0
	elif tp[0]=='b':
		exp="(\S+.*)[#!]\S+"
		r_rd=re.findall(exp,rd)
		if len(r_rd)==0:
			exp="(\S+.*\S+)\s*"
			r_rd=re.findall(exp,rd)
		r_ll=re.findall(exp,ll)
		#print r_rd,r_ll
		if r_rd==r_ll:
			return 1
		else:
			return 0

def inst_find_id_func(line,now_id):
	exp="%(\d+) = .*"
	r=re.findall(exp,line)
	if len(r)>0:#this is a line with id
		if now_id>=int(r[0]):
			now_id=[int(r[0]),now_id-int(r[0])+1]#if we found this id in IR is >= the previous, there is an error
		else:
			now_id=int(r[0])
		return now_id,[],0
	exp="<label>:(\d+):"
	r=re.findall(exp,line)
	if len(r)>0:#this is a line with id
		if now_id>=int(r[0]):
			now_id=[int(r[0]),now_id-int(r[0])+1]
		else:
			now_id=int(r[0])
		return now_id,[],0
	exp="define .* @(\S+)\((.*)\) .* \{"
	r=re.findall(exp,line)
	if len(r)>0:#this is a line of function begin
		#find out the start up id
		param=r[0][1]
		param=re.sub('\{.*?\}','REP',param)
		param=re.sub('\(.*?\)','',param)
		param=re.sub(' ','',param)
		param=param.split(',')
		count=0
		for p in param:
			if len(p)>0 and p!='...':
				count+=1
		return count,r[0][0],0
	exp="^\s*\}\s*"
	r=re.findall(exp,line)
	if len(r)>0:#this is a line of function begin
		return now_id,[],1
	return now_id,[],0

def inst_add_rule_find(eid,rule):
	for r in rule:
		if eid>=r[0][0] and (r[0][1]==[] or eid<=r[0][1]):
			return r[1]
	return -1

def inst_match_target(sl,text):
	if sl=='s':
		#exp="store .*,(?![^(]*\\)) (.*),(?![^(]*\\)) align \S+"
		exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
		r=re.findall(exp,text)
		return r
	elif sl=='l':
		#exp="%\S+ = load .*,(?![^(]*\\)) (.*),(?![^(]*\\)) align \S+"
		exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
		r=re.findall(exp,text)
		return r
	elif len(sl)>=2 and sl[0:2]=='bc':
		#print text
		exp="(%\S+) =.*call (.*) @"
		r=re.findall(exp,text)
		if len(r)>0:
			output=r[0][1]+' '+r[0][0]
		else:
			output=[]
		exp="\((.*)\)"
		r=re.findall(exp,text)
		r[0]+=','
		result=[[]]
		search=[6,5,4,3,2,1]
		for s in search:
			exp=""
			for i in range(s):
				exp+="(.*),(?![^(]*\\))(?![^{]*\\}) "
			exp=exp[0:-1]
			r2=re.findall(exp,r[0])
			if len(r2)>0:
				result=[[rr for rr in r2[0]]]
				break
		"""
		exp="(.*),(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\})"
		r2=re.findall(exp,r[0])
		if len(r2)==0:
			exp="(.*),(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\})"
			r2=re.findall(exp,r[0])
		r=[[rr for rr in r2[0]]]
		"""
		if output!=[]:
			result[0].append(output)
		#print result
		return result
	return ['']

def rds_rename(rds):
	#the format of input: array of [load node id, [store node ids]]
	drs=[]
	i=0
	for r in rds:
		i_dn=0
		for d in r[1]:
			while 1:
				if i_dn>=len(drs):
					drs.append([d,[r[0]]])
					i_dn+=1
					break
				elif d>drs[i_dn][0]:
					i_dn+=1
				elif d<drs[i_dn][0]:
					drs.insert(i_dn,[d,[r[0]]])
					break
				else:
					drs[i_dn][1].append(r[0])
					i_dn+=1
					break
		i+=1
	
	#rename
	now_name=1
	names=[]#old_name, new_name
	for r in rds:
		if r[0]!=[] and r[1]!=[]:
			now_name+=1
			names.append([r[0],now_name])
	
	drs=sorted(drs,key=lambda x: x[1])
	
	now_d=[]
	for d in drs:
		if d[1]!=now_d:
			now_d=d[1]
			now_name+=1
			names.append([d[0],now_name])
		else:
			names.append([d[0],now_name])
	names=sorted(names,key=lambda x: x[0])
	"""
	for n in names:
		print n
	"""
	for r in rds:
		i_n=0
		while 1:
			if r[0]==[]:
				break
			elif i_n>=len(names):
				now_name+=1
				names.append([r[0],now_name])
				i_n+=1
				break
			elif r[0]<names[i_n][0]:
				now_name+=1
				names.insert(i_n,[r[0],now_name])
				break
			elif r[0]>names[i_n][0]:
				i_n+=1
			else:
				break
	names=sorted(names,key=lambda x: x[0])
	return names

def rds_membership_rename(rds):
	i=0
	while i<len(rds):
		rds[i].extend([len(rds[i][1]),i])
		i+=1
	rds=sorted(rds,key=lambda x: x[2])
	rds.reverse()
	
	names=[]
	now_id=1
	#rename the identifier in reaching definition set first
	for r in rds:
		for d in r[1]:
			found=0
			i=0
			while i<len(names):
				if names[i][0]==d:
					found=1
					break
				i+=1
			if found==0:
				names.append([d,now_id])
				now_id+=1
	#rename the load id then
	for r in rds:
		found=0
		i=0
		if r[0]!=[]:
			while i<len(names):
				if names[i][0]==r[0]:
					found=1
					break
				i+=1
			if found==0:
				names.append([r[0],now_id])
				now_id+=1
	names=sorted(names,key=lambda x: x[0])
	return names

def rds_rename_perform(renames,rds):
	#rename the node id
	renames_ids=[r[0] for r in renames]
	i_r=0
	while i_r<len(rds):
		if rds[i_r][0]!=[]:
			rds[i_r][0]=renames[renames_ids.index(rds[i_r][0])][1]
		i_r+=1
	"""
	i_rn=0
	i_r=0
	while i_r<len(rds) and i_rn<len(renames):
		if rds[i_r][0]!=[]:
			if rds[i_r][0]<renames[i_rn][0]:
				i_r+=1
			elif rds[i_r][0]>renames[i_rn][0]:
				i_rn+=1
			else:
				rds[i_r][0]=renames[i_rn][1]
				i_r+=1
				i_rn+=1
		else:
			i_r+=1
	"""
	#rename ids in reaching definition set
	i=0
	while i<len(rds):
		i_rn=0
		i_d=0
		while i_d<len(rds[i][1]) and i_rn<len(renames):
			if rds[i][1][i_d]<renames[i_rn][0]:
				i_d+=1
			elif rds[i][1][i_d]>renames[i_rn][0]:
				i_rn+=1
			else:
				rds[i][1][i_d]=renames[i_rn][1]
				i_d+=1
				i_rn+=1
		rds[i][1]=sorted(list(set(rds[i][1])))
		i+=1
	return rds

def rds_delete(rds):
	#this is for delete the identifier(stores) that is not in the list
	count_d=0
	all_rds0=[r[0] for r in rds]
	delete=[]
	i=0
	while i<len(all_rds0):
		if all_rds0[i]==[]:
			delete.append(i)
		i+=1
	delete.reverse()
	for d in delete:
		del all_rds0[d]
	all_rds0=sorted(list(set(all_rds0)))
	i=0
	while i<len(rds):
		i_d=0
		i_r=0
		delete=[]
		while i_r<=len(all_rds0) and i_d<len(rds[i][1]):
			if i_r<len(all_rds0):
				if all_rds0[i_r]<rds[i][1][i_d]:
					i_r+=1
				elif all_rds0[i_r]>rds[i][1][i_d]:
					delete.append(i_d)
					i_d+=1
				else:
					i_r+=1
					i_d+=1
			else:
				delete.append(i_d)
				i_d+=1
		delete.reverse()
		for d in delete:
			del rds[i][1][d]
		i+=1

def inst_ll_random_delete(inst_records,ptg):
	delete=[]
	sl_count=0
	delete_old=[]#this is for in case it will be used by inst_ll_old
	i=0
	while i<len(inst_records):
		if inst_records[i][1] in ['s','l']:
			value=random.randint(0,99)
			if value<ptg:
				delete.append(i)
				delete_old.append(sl_count)
		if inst_records[i][1] in ['s','l','f','e']:
			sl_count+=1
		i+=1
	
	with open('random_delete_record'+rand_del_file_suffix, 'wb') as f:
		pickle.dump([delete,delete_old],f)
	f=open('random_delete_record_disp'+rand_del_file_suffix,'wb')
	for d in delete:
		f.write(str(d)+'\n')
	f.close()
	return delete

def inst_initialize_func(text,mode):
	i=0
	linemain=-1
	while i<len(text):
		exp='define .* @main\(.*\) .* \{'
		if len(re.findall(exp,text[i]))>0:
			linemain=i
			break
		i+=1
	if mode=='soft':
		text.insert(linemain+1,'call void @'+sfunc['init_soft_dfi']+'()\n')

def inst_ll(idinst,ll_name,ll_out_name):
	
	text=read_file(ll_name)
	replace_intrinsic_func(text)
	#make_align4(text)
	if endtimestamp:
		inst_timestamp(text)
	
	#delete llvm.lifetime function call's instrumentation
	i_i=0
	llvmlifetimecount=0
	while i_i<len(idinst):
		if idinst[i_i]['type']=='bc' and "llvm.lifetime" in idinst[i_i]['inst']:
			idinst[i_i]['del']=1
			llvmlifetimecount+=1
		i_i+=1
	print 'delete llvm.liftime',llvmlifetimecount
	
	#delete unnecessary check
	emptyrds=0
	i_i=0
	while i_i<len(idinst):
		if idinst[i_i]['type']=='l' and len(idinst[i_i]['rds'])==0:
			idinst[i_i]['del']=1
			emptyrds+=1
		i_i+=1
	print 'delete empty rds',emptyrds
	
	#find out after which lines we should add instrumented code
	inst_records=[]#text pos,type,node id(rd analysis),last element id,target/func name
	rds=[]
	i_i=0
	i_t=0
	now_id=-1
	last_f=-1
	invalid=[]
	idinst.append({'type':'s','inst':'dummy'})
	while i_i<len(idinst) and i_t<len(text):
		if idinst[i_i]['type'] in ['s','l','bc','bt']:
			record_type=idinst[i_i]['type']
			if idinst[i_i]['type']=='bc':
				sp_inst_func=check_if_special_inst_func(idinst[i_i]['inst'])
				if sp_inst_func==-1:
					i_i+=1
					continue
				#print idinst[i_i]
				record_type+=str(sp_inst_func)
			old_id=now_id
			now_id,fname,isend=inst_find_id_func(text[i_t],old_id)
			if type(now_id)==list:
				print 'variable id extraction error, now try to automatically fix'
				i_fix=len(inst_records)-1
				while i_fix>=0:
					inst_records[-1][3]-=now_id[1]
					if inst_records[-1][1]=='f':
						break
					i_fix-=1
				now_id=now_id[0]
			if fname!=[]:
				inst_records.append([i_t,'f',[],now_id,fname])
				rds.append([[],[]])
			if isend:
				inst_records.append([i_t,'e',[],now_id,''])
				rds.append([[],[]])
			if i_i!=len(idinst)-1 and inst_cmp_rd_ll(idinst[i_i]['type'],idinst[i_i]['inst'],text[i_t]):
				#print idinst[i_i]['inst'],text[i_t]
				#print record_type,'|',idinst[i_i]['type'],'|',idinst[i_i]['inst'],'|',text[i_t]
				r=inst_match_target(record_type,text[i_t])
				#print i_i,len(idinst),idinst[i_i]['inst'],text[i_t],r
				if(idinst[i_i]['del']):
					invalid.append(len(inst_records))
				if idinst[i_i]['type'] in ['bc','bt']:#if we instrument bc and bt in front of them, we should set the "id to this instr" the old_id
					if idinst[i_i]['type']=='bt' or sp_inst_funcs[sp_inst_func]['pos']==0:
						inst_records.append([i_t,record_type,idinst[i_i]['id'],old_id,r[0]])
					else:
						inst_records.append([i_t,record_type,idinst[i_i]['id'],now_id,r[0]])
				else:
					inst_records.append([i_t,record_type,idinst[i_i]['id'],now_id,r[0]])
				rds.append([idinst[i_i]['id'],idinst[i_i]['rds']])
				i_i+=1
			i_t+=1
		else:
			i_i+=1
	
	if i_i<len(idinst)-1:
		print "ERROR, .rd not match .ll",idinst[i_i],i_i,len(idinst)
		exit(1)
	print '1.extract basic information'
	"""
	for ii in idinst:
		print ii
	"""
	#delete the invalid instructions
	invalid.reverse()
	for d in invalid:
		del inst_records[d]
		del rds[d]
	
	#exit(1)
	#delete special functions
	delete=[]
	i=0
	while i<len(inst_records):
		if inst_records[i][1]=='f':
			found=0
			for ef in exfuncs:
				if len(re.findall(ef,inst_records[i][4]))>0:
					found=1
					break
			if found:
				j=i
				while j<len(inst_records):
					if inst_records[j][1]=='e':
						break
					j+=1
				delete.append([i,j])
				i=j
			else:
				i+=1
		else:
			i+=1
	delete.reverse()
	for d in delete:
		i=d[1]
		while i>=d[0]:
			del inst_records[i]
			del rds[i]
			i-=1
	#exit(1)
	print '2.delete extra information complete'
	
	delete_list=[0 for ir in inst_records]
	delete=[]
	
	if rand_del and rand_del_ptg>0:
		delete=inst_ll_random_delete(inst_records,rand_del_ptg)
		delete.reverse()
		for d in delete:
			del inst_records[d]
			del rds[d]
		print 'sp1.random delete complete'
	
	if load_del:
		with open(load_del_name, 'r') as f:
			packet=pickle.load(f)
		delete=packet[1]
		delete.reverse()
		for d in delete:
			del inst_records[d]
			del rds[d]
		print 'sp2.load delete complete'
	
	"""
	for d in delete:
		delete_list[d]=1
	"""
	
	#find out how much should be added on id, and the base id of each instrumented part
	
	now_add=0
	i=0
	for ir in inst_records:
		if ir[1]=='f':
			inst_records[i].append(0)
			now_add=inst_init(1,[])
		elif ir[1]=='s':
			inst_records[i].append(now_add)
			now_add+=inst_sl(1,[],[],[],[],'s',rds[i][1],0)#before
			now_add+=inst_sl(1,[],[],[],[],'s',rds[i][1],1)#after
		elif ir[1]=='l':
			inst_records[i].append(now_add)
			now_add+=inst_sl(1,[],[],[],[],'l',rds[i][1],0)
			now_add+=inst_sl(1,[],[],[],[],'l',rds[i][1],1)
		elif len(ir[1])>=2 and ir[1][0:2]=='bc':
			inst_records[i].append(now_add)
			now_add+=inst_sl(1,[],[],ir[4],[],ir[1],rds[i][1],0)
		elif ir[1]=='bt':
			inst_records[i].append(now_add)
			now_add+=inst_sl(1,[],[],ir[4],[],ir[1],rds[i][1],0)
		else:
			inst_records[i].append(now_add)
		i+=1
	
	add_records=[]
	now_line=0
	last_id=-1
	now_id=0
	for ir in inst_records:
		if ir[1]=='f':
			last_id=-1
			now_line=ir[0]
		now_id=ir[3]
		if last_id!=now_id:
			#print now_line, last_id,now_id,ir
			add_records.append([[now_line,[]],[last_id+1,now_id],ir[-1]])
			last_id=now_id
		if ir[1]=='e':
			i=len(add_records)-1
			while i>=0:
				if add_records[i][0][1]==[]:
					add_records[i][0][1]=ir[0]
				else:
					break
				i-=1
	"""
	for a in add_records:
		print '--)))',a
	"""
	#exit(1)
	
	add_rule=[]
	now_line=[]
	i=0
	while i<len(add_records):
		if add_records[i][0]!=now_line:
			now_line=add_records[i][0]
			add_rule.append([now_line,[]])
		add_rule[-1][1].append([add_records[i][1],add_records[i][2]])
		i+=1
	del add_records
	"""
	print 'NO.2','-'*10
	for i in inst_records:
		print i
	"""
	"""
	print '-'*10
	for a in add_records:
		print a
	"""
	"""
	print '-'*10
	for a in add_rule:
		print a
	"""
	#exit(1)
	
	#add the original element ids
	
	i=0
	now_rule=0
	process=0
	process_end=0
	exp='%(\d+)'
	exp2='<label>:(\d+):'
	while i<len(text):
		while 1:
			if now_rule>=len(add_rule):
				process_end=1
				break
			if i<add_rule[now_rule][0][0]:
				process=0
				i+=1
				break
			if i>=add_rule[now_rule][0][0] and (add_rule[now_rule][0][1]==[] or i<=add_rule[now_rule][0][1]):
				process=1
				break
			if i>=add_rule[now_rule][0][0] and add_rule[now_rule][0][1]!=[] and i>add_rule[now_rule][0][1]:
				now_rule+=1
				process=0
				break
		if process_end:
			break
		if process==0:
			continue
		if now_rule>=0:
			results=re.finditer(exp,text[i])
			need_add=[]
			for r in results:
				se=[r.start(),r.end()]
				eid=int(text[i][se[0]+1:se[1]])
				add=inst_add_rule_find(eid,add_rule[now_rule][1])
				need_add.append([se[0]+1,se[1],str(eid+add)])
			results=re.finditer(exp2,text[i])
			for r in results:
				se=[r.start(),r.end()]
				eid=int(text[i][se[0]+8:se[1]-1])
				add=inst_add_rule_find(eid,add_rule[now_rule][1])
				need_add.append([se[0]+8,se[1]-1,str(eid+add)])
			need_add=sorted(need_add,key=lambda x: x[0])
			need_add.reverse()
			for n in need_add:
				text[i]=text[i][0:n[0]]+n[2]+text[i][n[1]:]
		i+=1
	
	#revise the gadgets in inst_record
	"""
	print 'NO.3','-'*10
	for i in inst_records:
		print i
	"""
	i=0
	now_rule=-1
	while i<len(inst_records):
		while now_rule+1<len(add_rule) and inst_records[i][0]>=add_rule[now_rule+1][0][0] and (add_rule[now_rule+1][0][1]==[] or inst_records[i][0]<=add_rule[now_rule+1][0][1]):
			now_rule+=1
		if now_rule>=0:
			if type(inst_records[i][4])==str:
				results=re.finditer(exp,inst_records[i][4])
				need_add=[]
				for r in results:
					se=[r.start(),r.end()]
					eid=int(inst_records[i][4][se[0]+1:se[1]])
					add=inst_add_rule_find(eid,add_rule[now_rule][1])
					need_add.append([se[0]+1,se[1],str(eid+add)])
				need_add=sorted(need_add,key=lambda x: x[0])
				need_add.reverse()
				for n in need_add:
					inst_records[i][4]=inst_records[i][4][0:n[0]]+n[2]+inst_records[i][4][n[1]:]
				#print add_rule[now_rule],'|||',inst_records[i]
				#inst_records[i][3]+=inst_add_rule_find(inst_records[i][3],add_rule[now_rule][1])
			else:
				for i_4 in range(len(inst_records[i][4])):
					results=re.finditer(exp,inst_records[i][4][i_4])
					need_add=[]
					for r in results:
						se=[r.start(),r.end()]
						eid=int(inst_records[i][4][i_4][se[0]+1:se[1]])
						add=inst_add_rule_find(eid,add_rule[now_rule][1])
						need_add.append([se[0]+1,se[1],str(eid+add)])
					need_add=sorted(need_add,key=lambda x: x[0])
					need_add.reverse()
					for n in need_add:
						inst_records[i][4][i_4]=inst_records[i][4][i_4][0:n[0]]+n[2]+inst_records[i][4][i_4][n[1]:]
					#print add_rule[now_rule],'|||',inst_records[i]
					#inst_records[i][3]+=inst_add_rule_find(inst_records[i][3],add_rule[now_rule][1])
		i+=1
	"""
	for a in add_rule:
		print '========++++',a[0]
		for r in a[1]:
			print r
	"""
	#revise the last element id in inst_record, and add the init_base_id
	i=0
	line_count=0
	while i<len(inst_records):
		if inst_records[i][1]=='f':
			line_count=0
			j=i
			while j<len(inst_records):
				if inst_records[j][1]=='e':
					break
				j+=1
			diff=[0 for k in range(j-i)]
			k=i+1
			#print i,j,k,len(diff)
			while k<=j:
				diff[k-i-1]=inst_records[k][3]-inst_records[k-1][3]
				k+=1
		else:
			if line_count==0:
				inst_records[i][3]=inst_records[i-1][3]+diff[line_count]+inst_init(1,[])
			elif inst_records[i-1][1]=='s':
				inst_records[i][3]=inst_records[i-1][3]+diff[line_count]+inst_sl(1,[],[],[],[],'s',rds[i-1][1],0)+inst_sl(1,[],[],[],[],'s',rds[i-1][1],1)
			elif inst_records[i-1][1]=='l':
				inst_records[i][3]=inst_records[i-1][3]+diff[line_count]+inst_sl(1,[],[],[],[],'l',rds[i-1][1],0)+inst_sl(1,[],[],[],[],'l',rds[i-1][1],1)
			elif len(inst_records[i-1][1])>=2 and inst_records[i-1][1][0:2]=='bc':
				inst_records[i][3]=inst_records[i-1][3]+diff[line_count]+inst_sl(1,[],[],inst_records[i-1][4],[],inst_records[i-1][1],rds[i-1][1],0)
			elif inst_records[i-1][1]=='bt':
				inst_records[i][3]=inst_records[i-1][3]+diff[line_count]+inst_sl(1,[],[],inst_records[i-1][4],[],inst_records[i-1][1],rds[i-1][1],0)
			line_count+=1
		i+=1
	
	now_init_base_id=0
	i=0
	for ir in inst_records:
		if ir[1]=='f':
			now_init_base_id=ir[3]+1
			inst_records[i].append(now_init_base_id)
		elif ir[1]=='s' or ir[1]=='l' or (len(ir[1])>2 and ir[1][0:2]=='bc') or ir[1]=='bt':
			inst_records[i].append(now_init_base_id)
		i+=1
	"""
	print 'NO.4','-'*10
	for i in inst_records:
		print i
	"""
	#exit(1)
	
	#instrument
	i=0
	rds.reverse()
	inst_records.reverse()
	for ir in inst_records:
		if ir[1]=='f':
			add=inst_init(0,ir[-1]);
			add.reverse()
			text.insert(ir[0]+1,'<<<<<E<<<<<\n')
			#text.insert(ir[0]+1,'\n')
			for t in add:
				text.insert(ir[0]+1,t)
			text.insert(ir[0]+1,'>>>>>S>>>>>\n')
			#text.insert(ir[0]+1,'\n')
		elif ir[1]=='s' or ir[1]=='l':#instrument after them
			add=inst_sl(0,ir[3]+1,ir[-1],ir[4],ir[2],ir[1],rds[i][1],1);
			add.reverse()
			text.insert(ir[0]+1,'<<<<<E<<<<<'+ir[1]+'\n')
			#text.insert(ir[0]+1,'\n')
			for t in add:
				text.insert(ir[0]+1,t)
			text.insert(ir[0]+1,'>>>>>S>>>>>'+ir[1]+'\n')
			#text.insert(ir[0]+1,'\n')
			add=inst_sl(0,ir[3]+1,ir[-1],ir[4],ir[2],ir[1],rds[i][1],0);
			add.reverse()
			text.insert(ir[0],'<<<<<E<<<<<'+ir[1]+'\n')
			#text.insert(ir[0]+1,'\n')
			for t in add:
				text.insert(ir[0],t)
			text.insert(ir[0],'>>>>>S>>>>>'+ir[1]+'\n')
			#text.insert(ir[0]+1,'\n')
		elif (len(ir[1])>2 and ir[1][0:2]=='bc') or ir[1]=='bt':#instrument before them
			if ir[1]=='bt' or sp_inst_funcs[int(ir[1][2:])]['pos']==0:
				add=inst_sl(0,ir[3]+1,ir[-1],ir[4],ir[2],ir[1],rds[i][1],0);
				add.reverse()
				text.insert(ir[0],'<<<<<E<<<<<'+ir[1]+'\n')
				for t in add:
					text.insert(ir[0],t)
				text.insert(ir[0],'>>>>>S>>>>>'+ir[1]+'\n')
			else:
				add=inst_sl(0,ir[3]+1,ir[-1],ir[4],ir[2],ir[1],rds[i][1],1);
				add.reverse()
				text.insert(ir[0]+1,'<<<<<E<<<<<'+ir[1]+'\n')
				for t in add:
					text.insert(ir[0]+1,t)
				text.insert(ir[0]+1,'>>>>>S>>>>>'+ir[1]+'\n')
		i+=1
	
	# extract the phi node
	phi_nodes=[]
	i=0
	for t in text:
		exp="%\S+ = phi .*"
		if len(re.findall(exp,t))>0:
			#exp="\[ (\S+), (\S+) \]"
			exp="\[ (.*?), (\S+) \]"
			r=re.findall(exp,t)
			temp=[]
			for branch in r:
				temp.append([i,branch[0],branch[1]])
			phi_nodes[-1][1].extend(temp)
			i+=1
			continue
		exp="define .* @(\S+)\((.*)\) .* \{"
		r=re.findall(exp,t)
		if len(r)>0:
			phi_nodes.append([r[0][0],[]])
			i+=1
			continue
		i+=1
	"""
	for p in phi_nodes:
		print p
	"""
	print '-1.extract phi nodes'
	
	#revise the phi node
	label_change=[]
	in_inst=0
	now_label=[-1,-1]
	exp="; <label>:(\d+):"
	exp2="UnifiedReturnBlock:"
	expf="define .* @(\S+)\((.*)\) .* \{"
	expfe="^\s*\}\s*"
	exps=">>>>>S>>>>>"
	expe="<<<<<E<<<<<"
	for t in text:
		#print t
		#print now_label
		#print in_inst
		if in_inst==0:
			r=re.findall(exps,t)
			if len(r)>0:
				in_inst=1
				continue
			r=re.findall(exp,t)
			if len(r)>0:
				label_change[-1][1].append(now_label)
				now_label=[int(r[0]),int(r[0])]
				continue
			r=re.findall(exp2,t)
			if len(r)>0:
				label_change[-1][1].append(now_label)
				now_label=[-1,-1]
				continue
			r=re.findall(expf,t)
			if len(r)>0:
				label_change.append([r[0][0],[]])
				param=r[0][1]
				param=re.sub('\{.*?\}','REP',param)
				param=re.sub('\(.*?\)','',param)
				param=re.sub(' ','',param)
				param=param.split(',')
				count=0
				for p in param:
					if len(p)>0 and p!='...':
						count+=1
				now_label=[count,count]
				continue
			r=re.findall(expfe,t)
			if len(r)>0:
				label_change[-1][1].append(now_label)
				continue
		else:
			r=re.findall(exp,t)
			if len(r)>0:
				now_label[1]=int(r[0])
				continue
			r=re.findall(expe,t)
			if len(r)>0:
				in_inst=0
				continue
	"""
	for l in label_change:
		print l
	"""
	#exit(1)
	if len(label_change)!=len(phi_nodes):
		print 'ERROR, label_change or phi_nodes reads error'
		exit(1)
	i=0
	i_l=-1
	while i<len(label_change):
		#print phi_nodes[i][1]
		i_p=0
		while i_p<len(phi_nodes[i][1]):
			line=phi_nodes[i][1][i_p][0]
			prev=int(phi_nodes[i][1][i_p][2][1:])
			#print '='*10,prev
			#print label_change[i][1]
			i_l=0
			while i_l<len(label_change[i][1]):
				if prev==label_change[i][1][i_l][0]:
					#print label_change[i][1][i_l]
					text[line]=re.sub('%'+str(prev)+' \]','%'+str(label_change[i][1][i_l][1])+' ]',text[line])
					break
				i_l+=1
			i_p+=1
		i+=1
	
	#delete the mark
	exps=">>>>>S>>>>>"
	expe="<<<<<E<<<<<"
	i=0
	while i<len(text):
		if len(text[i])>=11 and (text[i][0:11]==exps or text[i][0:11]==expe):
			text[i]='\n'
		i+=1
	
	#exchange initialize function to the first line of main
	inst_initialize_func(text,exp_mode)
	
	if debugfunc == 1:
		inst_debug(text)
	
	#exit(1)
	f=open(ll_out_name,'wb')
	for t in text:
		f.write(t)
	f.close()

def idinst_opt_rename(idinst):
	
	rds=[[ii['id'],[]] for ii in idinst]
	#we only care about store and load
	i=0
	while i<len(idinst):
		if idinst[i]['type']!='s' and idinst[i]['type']!='l' and idinst[i]['type']!='bc':
			rds[i][0]=[]
		i+=1
	#generate the reaching definition sets
	i_r=0
	i_i=0
	while i_r<len(rds) and i_i<len(idinst) and idinst[i_i]['inst']!='dummy':
		if rds[i_r][0]==[] or rds[i_r][0]<idinst[i_i]['id']:
			i_r+=1
		elif rds[i_r][0]>idinst[i_i]['id']:
			i_i+=1
		else:
			rds[i_r][1]=idinst[i_i]['rds']
			i_r+=1
			i_i+=1
	#get the new name
	renames=rds_rename(rds)
	rds=rds_rename_perform(renames,rds)
	
	#delete the out of range definition identifier
	rds_delete(rds)
	
	#do membership check opt
	renames=rds_membership_rename(rds)
	rds=rds_rename_perform(renames,rds)
	
	#rewrite the result to idinst. NOTE, this will delete all the node id except store and load
	i=0
	while i<len(idinst):
		idinst[i]['id']=rds[i][0]
		idinst[i]['rds']=rds[i][1]
		i+=1

def idinst_opt_setcheckdef(idinst):
	#this is for idinst optimization, two intrumentations should be in the same basic block, related to same data.
	#opt1, same identifier
	i=0
	delete=[]
	while i<len(idinst):
		if idinst[i]['type']=='s':
			exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
			r=re.findall(exp,idinst[i]['inst'])
			data=r[0]
			j=i+1
			while j<len(idinst):
				if idinst[j]['type']=='s':
					exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						if idinst[i]['id']==idinst[j]['id']:
							if not (j in delete):
								idinst[j]['del']=1
								#delete.append(j)
						break
				elif idinst[j]['type'][0]=='b':
					break
				j+=1
		i+=1
	#print delete
	delete=sorted(list(set(delete)))
	delete.reverse()
	for d in delete:
		#print idinst[d]['inst']
		del idinst[d]
	#opt2, no checkdef
	i=0
	delete=[]
	while i<len(idinst):
		if idinst[i]['del']:
			i+=1
			continue
		if idinst[i]['type']=='s':
			exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
			r=re.findall(exp,idinst[i]['inst'])
			data=r[0]
			j=i+1
			while j<len(idinst):
				if idinst[j]['del']:
					j+=1
					continue
				if idinst[j]['type']=='s':
					exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						if not (i in delete):
							idinst[i]['del']=1
							#delete.append(i)
						break
				elif idinst[j]['type']=='l':
					exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						break
				elif idinst[j]['type'][0]=='b':
					break
				j+=1
		i+=1
	#print delete
	delete=sorted(list(set(delete)))
	delete.reverse()
	for d in delete:
		del idinst[d]
	#opt3, checkdef right after setdef
	i=0
	delete=[]
	while i<len(idinst):
		if idinst[i]['del']:
			i+=1
			continue
		if idinst[i]['type']=='s':
			exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
			r=re.findall(exp,idinst[i]['inst'])
			data=r[0]
			j=i+1
			while j<len(idinst):
				if idinst[j]['del']:
					j+=1
					continue
				if idinst[j]['type']=='s':
					exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						break
				elif idinst[j]['type']=='l':
					exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0] and (idinst[i]['id'] in idinst[j]['rds']):
						if not (j in delete):
							idinst[j]['del']=1
							#delete.append(j)
				elif idinst[j]['type'][0]=='b':
					break
				j+=1
		i+=1
	delete=sorted(list(set(delete)))
	delete.reverse()
	for d in delete:
		del idinst[d]
	#opt4, later checkdef can only check former checkdef
	i=0
	delete=[]
	while i<len(idinst):
		if idinst[i]['del']:
			i+=1
			continue
		if idinst[i]['type']=='l':
			exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
			r=re.findall(exp,idinst[i]['inst'])
			data=r[0]
			j=i+1
			while j<len(idinst):
				if idinst[j]['del']:
					j+=1
					continue
				if idinst[j]['type']=='s':
					exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						break
				elif idinst[j]['type']=='l':
					exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						if idinst[i]['rds']==idinst[j]['rds']:
							if not (j in delete):
								idinst[j]['del']=1
								#delete.append(j)
							break
						else:
							delete2=[]
							i_r=0
							while i_r<len(idinst[j]['rds']):
								if idinst[j]['rds'][i_r] not in idinst[i]['rds']:
									delete2.append(i_r)
								i_r+=1
							delete2.reverse()
							for d in delete2:
								del idinst[j]['rds'][d]
							break
				elif idinst[j]['type'][0]=='b':
					break
				j+=1
		i+=1
	#print delete
	delete=sorted(list(set(delete)))
	delete.reverse()
	for d in delete:
		del idinst[d]
	#opt5, delete setdef if it is just checked
	i=0
	delete=[]
	while i<len(idinst):
		if idinst[i]['del']:
			i+=1
			continue
		if idinst[i]['type']=='l':
			exp="%\S+ = load .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
			r=re.findall(exp,idinst[i]['inst'])
			data=r[0]
			j=i+1
			while j<len(idinst):
				if idinst[j]['del']:
					j+=1
					continue
				if idinst[j]['type']=='s':
					exp="store .*,(?![^(]*\\))(?![^{]*\\}) (.*),(?![^(]*\\))(?![^{]*\\}) align \S+"
					r=re.findall(exp,idinst[j]['inst'])
					if data==r[0]:
						if idinst[i]['rds']==[idinst[j]['id']]:
							if j not in delete:
								idinst[j]['del']=1
								#delete.append(j)
						break
				elif idinst[j]['type'][0]=='b':
					break
				j+=1
		i+=1
	#print delete
	delete=sorted(list(set(delete)))
	delete.reverse()
	for d in delete:
		del idinst[d]
	
def analysis_code(idinst):
	n_s=0
	n_l=0
	n_br=0
	n_bc=0
	n_bs=0
	n_bt=0
	for ii in idinst:
		if ii['type']=='br':
			n_br+=1
		elif ii['type']=='bc':
			n_bc+=1
		elif ii['type']=='bs':
			n_bs+=1
		elif ii['type']=='bt':
			n_bt+=1
		elif ii['type']=='l':
			n_l+=1
		elif ii['type']=='s':
			n_s+=1
	
	print 'store count '+str(n_s)+'. '+str(float(n_s)/len(idinst)*100)+'%'
	print 'load count '+str(n_l)+'. '+str(float(n_l)/len(idinst)*100)+'%'
	print 'branch count '+str(n_br)+'. '+str(float(n_br)/len(idinst)*100)+'%'
	print 'call count '+str(n_bc)+'. '+str(float(n_bc)/len(idinst)*100)+'%'
	print 'switch count '+str(n_bs)+'. '+str(float(n_bs)/len(idinst)*100)+'%'
	print 'ret count '+str(n_bt)+'. '+str(float(n_bt)/len(idinst)*100)+'%'
	

def show_delete_inst(inst_records,show_del_range):
	for i in range(show_del_range):
		with open('random_delete_record_'+str(i), 'r') as f:
			[delete,delete_old]=pickle.load(f)
		print '====='+str(i)+'====='
		for d in delete:
			print d,inst_records[d]

def get_all_special_exclusive_funcs():
	text=read_file(sfuncfile+'.ll')
	exp="define .* @(\S+)\((.*)\) .* \{"
	for t in text:
		r=re.findall(exp,t)
		if len(r)>0:
			nonexcludedfound=0
			for ne in nonexcluded:
				if len(re.findall(ne,r[0][0]))>0:
					nonexcludedfound=1
					break
			if nonexcludedfound:
				continue
			exfuncs.append(r[0][0])
			for sfk in sfunc.keys():
				if len(re.findall(sfk,r[0][0]))>0:
					sfunc[sfk]=r[0][0]
					break
	
def disp_statistic(idinst):
	n_s=0
	max_sid=0
	n_l=0
	max_lid=0
	for ii in idinst:
		if 'func' in ii.keys() and ii['func'] not in exfuncs:
			if ii['type']=='l':
				if ii['id']>max_lid:
					max_lid=ii['id']
				n_l+=1
			elif ii['type']=='s':
				if ii['id']>max_sid:
					max_sid=ii['id']
				n_s+=1
	print '# of store',n_s,'max id is',max_sid
	print '# of load',n_l,'max id is',max_lid

def usr_specify_rds(idinst,filename):
	text=read_file(filename)
	state=0
	for t in text:
		if state==0:
			uid=int(t)
			state=1
		else:
			urds=re.findall('(\S+)',t)
			mode=0
			if urds[0]=='+':
				mode=1#add mode
				del urds[0]
			elif urds[0]=='-':
				mode=2#delete mode
				del urds[0]
			elif urds[0]=='--':
				mode=3#delete all that have
				del urds[0]
			if mode==0:
				i=0
				while i<len(idinst):
					if idinst[i]['id']==uid:
						idinst[i]['rds']=[int(r) for r in urds]
						print 'user specified rds:',idinst[i]
						break
					i+=1
			elif mode==1:
				i=0
				while i<len(idinst):
					if idinst[i]['id']==uid:
						idinst[i]['rds'].extend([int(r) for r in urds])
						print 'user specified rds:',idinst[i]
						break
					i+=1
			elif mode==2:
				i=0
				while i<len(idinst):
					if idinst[i]['id']==uid:
						delete=[]
						for r in urds:
							if int(r) in idinst[i]['rds']:
								delete.append(idinst[i]['rds'].index(int(r)))
						delete=sorted(delete)
						delete.reverse()
						for d in delete:
							del idinst[i]['rds'][d]
						print 'user specified rds:',idinst[i]
						break
					i+=1
			else:
				i=0
				while i<len(idinst):
					found=0
					delete=[]
					for r in urds:
						if int(r) in idinst[i]['rds']:
							delete.append(idinst[i]['rds'].index(int(r)))
					delete=sorted(delete)
					delete.reverse()
					for d in delete:
						found=1
						del idinst[i]['rds'][d]
					if found:
						print 'user specified rds:',idinst[i]
					i+=1
			state=0

def make_align4(text):
	i=0
	while i<len(text):
		text[i]=text[i].replace("align 1","align 4")
		text[i]=text[i].replace("align 2","align 4")
		i+=1	

def get_ret_id(idinst):
	#function return id is the largest id+1
	global ret_id
	for ii in idinst:
		if ii['id']!=[] and ii['id']>ret_id:
			ret_id=ii['id']
		if len(ii['rds'])>0 and max(ii['rds'])>ret_id:
			ret_id=max(ii['rds'])
	ret_id+=1

def do_hdfi_change(idinst,filename):
	global ret_id
	
	ret_id=9999
	
	text=read_file(filename)
	changed=[]
	state=0
	for t in text:
		if state==0:
			uid=int(t)
			state=1
		else:
			urds=re.findall('(\S+)',t)
			mode=0
			if urds[0]=='s':
				mode=1
			del urds[0]
			if mode==0:
				i=0
				while i<len(idinst):
					if idinst[i]['id']==uid:
						idinst[i]['rds']=[int(r) for r in urds]
						print 'user specified rds:',idinst[i]
						changed.append(i)
						break
					i+=1
			elif mode==1:
				i=0
				while i<len(idinst):
					if idinst[i]['id']==uid:
						idinst[i]['id']=int(urds[0])
						print 'user specified rds:',idinst[i]
						changed.append(i)
						break
					i+=1
			state=0
	i=0
	while i<len(idinst):
		if i not in changed:
			if type(idinst[i]['id'])==int:
				idinst[i]['id']=9999
			if len(idinst[i]['rds'])>0:
				idinst[i]['rds']=[]
		i+=1

def extract_sl_old(i,insts,mark,mark2,num):
	#mark: special words
	#num: # of the special words for a group
	j=i
	while j<len(insts) and insts[j]==mark:
		j+=1
	size=(j-i)/num
	if size==0:
		return [[],0,j]
	temp=[]
	while j<len(insts) and insts[j]!=mark2:
		temp=insts[j]
		j+=1
	return temp,size,j+size*num

def extract_sl(i,insts,mark,mark2,num):
	#mark: special words
	#num: # of the special words for a group
	j=i
	size=0
	count=0
	state=0
	temp=[]
	while j<len(insts):
		if state==0:
			if insts[j]==mark:
				count+=1
			if count==num:
				count=0
				state=1
		elif state==1:
			if insts[j]==mark:
				state=0
				count=0
				temp=[]
				continue
			elif insts[j]==mark2:
				state=2
				count=0
				continue
			elif asm_test_sl_valid(insts[j]):
				temp=insts[j]
		elif state==2:
			if insts[j]==mark2:
				count+=1
			if count==num:
				count=0
				size+=1
				if temp==[] and j+1<len(insts) and insts[j+1]==mark:
					state=0
				else:
					return temp,size,j
		j+=1
	return [],0,j

def replace_intrinsic_func(text):
	exp="declare .* @(\S+)\(.*\)"
	exp2="\S+ = call [^@]* @([^\(]*)\(|\s*call [^@]* @([^\(]*)\(|\S+ = tail call [^@]* @([^\(]*)\(|\s*tail call [^@]* @([^\(]*)\("
	expl="llvm\.([^\.]+)\..*"
	i=0
	while i<len(text):
		t=text[i]
		r=re.findall(exp,t)
		if len(r)>0:
			#print r
			found=0
			for v in valid_intrinsic_func:
				if v in r[0]:
					found=1
					break
			if found:
				r2=re.findall(expl,r[0])
				if len(r2)>0:
					text[i]=text[i].replace(r[0],r2[0])
			i+=1
			continue
		r=re.findall(exp2,t)
		if len(r)>0:
			name=''
			for e in r[0]:
				if len(e)>0:
					name=e
					break
			found=0
			for v in valid_intrinsic_func:
				if v in name:
					found=1
					break
			if found:
				r2=re.findall(expl,name)
				if len(r2)>0:
					text[i]=text[i].replace(name,r2[0])
		i+=1

#=================================main=======================================s

if len(sys.argv)<2:
	print("Please input the program prefix")
	exit(1)

p=[]
for i in range(2,len(sys.argv)):
	if sys.argv[i][0]=='-':
		p.append(i)

for i in p:
	if sys.argv[i]=='-sfunc':
		sfuncfile=sys.argv[i+1]
	elif sys.argv[i]=='-usrrds':
		usr_rds=1
		usr_rds_file=sys.argv[i+1]
	elif sys.argv[i]=='-soft':
		exp_mode='soft'
		bf_len=16
	elif sys.argv[i]=='-hdfi':
		hdfi_mode=1
	elif sys.argv[i]=='-debugfunc':
		debugfunc=1
		print 'debugfunc is inserted'
	elif sys.argv[i]=='-allfunc':
		anyfunc=1
	elif sys.argv[i]=='-nofunc':
		nofunc=1
	elif sys.argv[i]=='-noload':
		noload=1
	elif sys.argv[i]=='-nostore':
		nostore=1

if sfuncfile!='':
	get_all_special_exclusive_funcs()
	print sfunc
	print exfuncs

text=read_file(sys.argv[1]+'.rd')
replace_intrinsic_func(text)
idinst=parse_analysis(text)
del text
print "Parse reaching definition analysis complete"
if usr_rds and hdfi_mode==0:
	usr_specify_rds(idinst,usr_rds_file)

if hdfi_mode==0:
	idinst_opt_rename(idinst)
	print 'Rename optimization complete'
	
	idinst_opt_setcheckdef(idinst)
	print 'Setdef/Checkdef optimization complete'
	
	get_ret_id(idinst)
	print 'Ret id is',ret_id

if usr_rds and hdfi_mode:
	do_hdfi_change(idinst,usr_rds_file)

if analysis:
	analysis_code(idinst)
	exit(0)

countdel=0
countsldel=0
countsl=0
for ii in idinst:
	if ii['type'] in ['s','l']:
		countsl+=1
		if ii['del']:
			countsldel+=1
	else:
		if ii['del']:
			#print ii
			countdel+=1
print 's/l count',countsl,'deleted s/l',countsldel,'deleted other',countdel
"""
for ii in idinst:
	print ii
"""

if nostore:
	i_i=0
	while i_i<len(idinst):
		if idinst[i_i]['type']=='s':
			idinst[i_i]['del']=1
		i_i+=1
if noload:
	i_i=0
	while i_i<len(idinst):
		if idinst[i_i]['type']=='l':
			idinst[i_i]['del']=1
		i_i+=1

inst_ll(idinst,sys.argv[1]+'.ll',sys.argv[1]+'.ll')
print "Instrument bitcode complete"

"""
print '==================='
for ii in idinst:
	if 'func' in ii.keys() and ii['func']=='main':
		print ii
"""

	
	
	
