$LLVMPATH/bin/clang -emit-llvm -c -o test.bc ${PROGPATH}/test.c -O0 -lpthread
